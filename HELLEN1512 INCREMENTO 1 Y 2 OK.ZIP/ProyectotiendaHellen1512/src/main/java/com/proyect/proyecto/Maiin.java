
package com.proyect.proyecto;
import Controlador.loginControlador;
import Vista.login;

public class Maiin {

    public static login log;
    public static loginControlador ctr;
    
    public static void main(String[] args) {
        log = new login();
        ctr = new loginControlador(log);
    }
}
