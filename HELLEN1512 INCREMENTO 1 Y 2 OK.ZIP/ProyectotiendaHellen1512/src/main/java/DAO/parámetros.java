
package DAO;

public interface parámetros {
    String DRIVER = "com.mysql.cj.jdbc.Driver";
    String RUTA = "jdbc:mysql://localhost:3306/HELLEN1512";
    String USUARIO = "root";
    String CLAVE = "axcc";
}
